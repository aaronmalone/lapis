****MATLAB LAPIS RELEASE 0.1 ALPHA****

1. To run, open two separate MATLAB instances in your operating system.  Make sure you point your
   current MATLAB directory to the folder with the jar file and the Lapis objects.  
2. In the first instance, open node1simulation.m.
3. In the second instance, open node2simulation.m.
4. Start the first instance with node1simulation.m first.  YOu should see it incrementing.
5. Start the second instance node2simulation.m right after the first instance is started.



